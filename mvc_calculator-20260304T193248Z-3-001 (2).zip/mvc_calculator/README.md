# MVC Calculator

## 📌 Deskripsyon Pwojè a

Pwojè sa a se yon kalkitatè amelyore ki bati avèk achitekti MVC (Model - View - Controller) an Python. Objektif li se separe responsabilite kòd la an twa gwo pati pou kòd la rete pwòp, fasil pou konprann ak fasil pou modifye.


## Achitekti MVC — Sa Chak Pati Fè


mvc_calculator/
│
├── model/
│   └── calculator_model.py     ← MODEL
│
├── view/
│   └── calculator_view.py      ← VIEW
│
├── controller/
│   └── calculator_controller.py ← CONTROLLER
│
├── tests/
│   └── test_calculator_model.py ← TÈS INITE
│
└── main.py                     ← Pwen antree pwogram nan
```

### MODEL ('model/calculator_model.py')
Se sèvo kalkitatè a. Li okipe tout kalkil matematik yo:
- Adisyon, soustraksyon, miltiplikasyon, divizyon
- Rasin kare (`sqrt`)
- Puisans (`power`)
- Modilo (`modulo`)
- Istwa operasyon yo (History)

MODEL pa konnen koman rezilta yo afiche. Li fè kalkil sèlman.

### VIEW ('view/calculator_view.py')
Se figi pwogram nan. Li okipe tout sa itilizatè a wè ak ekri:
- Afiche meni a
- Mande nimewo nan itilizatè a
- Montre rezilta yo
- Montre mesaj erè yo
- Afiche istwa kalkil yo

VIEW pa fè okenn kalkil. Li montre enfòmasyon sèlman.

### CONTROLLER ('controller/calculator_controller.py')
Se koneksyon ant MODEL ak VIEW. Li:
- Resevwa chwa itilizatè a nan VIEW
- Rele operasyon ki kòrèk nan MODEL
- Voye rezilta tounen bay VIEW pou afichaj
- Jere tout erè ki ka rive

---

## Operasyon Disponib

| # | Operasyon       | Senbòl | Ekzanp          |
|---|-----------------|--------|-----------------|
| 1 | Adisyon         | '+'   | 5 + 3 = 8       |
| 2 | Soustraksyon    | '-'    | 10 - 4 = 6      |
| 3 | Miltiplikasyon  | '*'    | 6 * 7 = 42      |
| 4 | Divizyon        | '/'    | 15 / 3 = 5      |
| 5 | Rasin kare      | 'sqrt' | sqrt(16) = 4    |
| 6 | Puisans         | '^'    | 2 ^ 8 = 256     |
| 7 | Modilo          | '%'    | 10 % 3 = 1      |
| 8 | Istwa kalkil yo | —      | Wè tout istwa   |
| 9 | Efase istwa     | —      | Retire istwa    |

---

## Jèsyon Erè (Error Handling)

Pwogram nan pwoteje kont:
- Divizyon pa zewo → mesaj erè klè
- Rasin kare yon nimewo negatif → mesaj erè klè
- Modilo pa zewo → mesaj erè klè
- Antre tèks olye nimewo → pwogram mande ankò otomatikman

---

## Koman Pou Kouri Pwogram Nan

### Pre-kondisyon
- Python 3.7 oswa pi wo

### Kouri kalkitatè a
'''bash
cd mvc_calculator
python main.py
'''

### Kouri tès inite yo
'''bash
cd mvc_calculator
python -m pytest tests/
# oswa
python -m unittest tests/test_calculator_model.py
'''

---

## Tès Inite (Unit Tests)

Fichye 'tests/test_calculator_model.py' teste:
- Tout operasyon matematik yo
- Jèsyon erè (zewo, nimewo negatif)
- Istwa — anrejistreman ak efasman

---

## Prensip MVC Eksplike Senplman

| Pati       | Rôl li          | Analogji reyèl                     |
|------------|-----------------|-------------------------------------|
| MODEL      | Kalkil          | Sèvo moun ki konn matematik         |
| VIEW       | Afichaj         | Ekran kalkitatè a — sa ou wè        |
| CONTROLLER | Kominikasyon    | Touche yo sou kalkitatè a           |

---

## Teknoloji Itilize

- **Langaj:** Python 3
- **Modil:** `math` (lib estanda Python)
- **Tès:** `unittest` (lib estanda Python)
- **Achitekti:** MVC (Model-View-Controller)


