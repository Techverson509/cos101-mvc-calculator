import sys
import os
import unittest

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from model.calculator_model import CalculatorModel


class TestCalculatorModel(unittest.TestCase):

    def setUp(self):
        self.model = CalculatorModel()

    # --- Basic Operations ---
    def test_add(self):
        self.assertEqual(self.model.add(3, 5), 8)

    def test_subtract(self):
        self.assertEqual(self.model.subtract(10, 4), 6)

    def test_multiply(self):
        self.assertEqual(self.model.multiply(3, 4), 12)

    def test_divide(self):
        self.assertEqual(self.model.divide(10, 2), 5)

    # Error Handling
    def test_divide_by_zero(self):
        with self.assertRaises(ValueError):
            self.model.divide(10, 0)

    def test_sqrt_negative(self):
        with self.assertRaises(ValueError):
            self.model.sqrt(-4)

    def test_modulo_by_zero(self):
        with self.assertRaises(ValueError):
            self.model.modulo(10, 0)

    #Extended Operations
    def test_sqrt(self):
        self.assertAlmostEqual(self.model.sqrt(9), 3.0)

    def test_power(self):
        self.assertEqual(self.model.power(2, 10), 1024)

    def test_modulo(self):
        self.assertEqual(self.model.modulo(10, 3), 1)

    # History
    def test_history_saved(self):
        self.model.save_to_history("3 + 5", 8)
        self.assertEqual(len(self.model.get_history()), 1)
        self.assertEqual(self.model.get_history()[0]["result"], 8)

    def test_history_cleared(self):
        self.model.save_to_history("3 + 5", 8)
        self.model.clear_history()
        self.assertEqual(len(self.model.get_history()), 0)


if __name__ == "__main__":
    unittest.main()
