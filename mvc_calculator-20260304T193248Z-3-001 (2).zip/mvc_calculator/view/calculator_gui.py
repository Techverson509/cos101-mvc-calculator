import tkinter as tk
from tkinter import font


class CalculatorGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Enhanced MVC Calculator")
        self.root.resizable(False, False)
        self.root.configure(bg="#1e1e2e")

        self.controller = None  

        self._build_ui()

    def set_controller(self, controller):
        self.controller = controller

    #  UI BUILDER
    def _build_ui(self):
        self._build_display()
        self._build_buttons()

    def _build_display(self):
        display_frame = tk.Frame(self.root, bg="#1e1e2e", pady=12, padx=12)
        display_frame.pack(fill="x")

        # History label (small line above)
        self.history_var = tk.StringVar(value="")
        tk.Label(
            display_frame,
            textvariable=self.history_var,
            font=("Consolas", 11),
            bg="#1e1e2e",
            fg="#6c7086",
            anchor="e",
        ).pack(fill="x", padx=4)

        # Main expression display
        self.expr_var = tk.StringVar(value="0")
        tk.Label(
            display_frame,
            textvariable=self.expr_var,
            font=("Consolas", 30, "bold"),
            bg="#1e1e2e",
            fg="#cdd6f4",
            anchor="e",
            wraplength=380,
            justify="right",
        ).pack(fill="x", padx=4)

    def _build_buttons(self):
        btn_frame = tk.Frame(self.root, bg="#1e1e2e", padx=10, pady=6)
        btn_frame.pack()

        # ── Button layout ──────────────────────────────────────
        buttons = [
            # Row 0 — History / Clear
            ("History", 0, 0, 1, "func"),
            ("Clr Hist", 0, 1, 1, "func"),
            ("CE", 0, 2, 1, "op"),
            ("⌫", 0, 3, 1, "op"),

            # Row 1 — special ops
            ("sqrt", 1, 0, 1, "func"),
            ("x^y", 1, 1, 1, "func"),
            ("mod", 1, 2, 1, "func"),
            ("/", 1, 3, 1, "op"),

            # Row 2
            ("7", 2, 0, 1, "num"),
            ("8", 2, 1, 1, "num"),
            ("9", 2, 2, 1, "num"),
            ("*", 2, 3, 1, "op"),

            # Row 3
            ("4", 3, 0, 1, "num"),
            ("5", 3, 1, 1, "num"),
            ("6", 3, 2, 1, "num"),
            ("-", 3, 3, 1, "op"),

            # Row 4
            ("1", 4, 0, 1, "num"),
            ("2", 4, 1, 1, "num"),
            ("3", 4, 2, 1, "num"),
            ("+", 4, 3, 1, "op"),

            # Row 5
            ("+/-", 5, 0, 1, "num"),
            ("0", 5, 1, 1, "num"),
            (".", 5, 2, 1, "num"),
            ("=", 5, 3, 1, "eq"),
        ]

        styles = {
            "num": {"bg": "#313244", "fg": "#cdd6f4", "active": "#45475a"},
            "op":  {"bg": "#45475a", "fg": "#89b4fa", "active": "#585b70"},
            "func":{"bg": "#45475a", "fg": "#a6e3a1", "active": "#585b70"},
            "eq":  {"bg": "#89b4fa", "fg": "#1e1e2e", "active": "#74c7ec"},
        }

        for (label, row, col, colspan, style) in buttons:
            s = styles[style]
            btn = tk.Button(
                btn_frame,
                text=label,
                font=("Consolas", 14, "bold"),
                bg=s["bg"],
                fg=s["fg"],
                activebackground=s["active"],
                activeforeground=s["fg"],
                relief="flat",
                bd=0,
                width=6,
                height=2,
                cursor="hand2",
                command=lambda l=label: self._on_button(l),
            )
            btn.grid(row=row, column=col, columnspan=colspan,
                     padx=4, pady=4, sticky="nsew")

        # History popup label
        self.history_popup = tk.Label(
            self.root,
            text="",
            font=("Consolas", 10),
            bg="#313244",
            fg="#cdd6f4",
            justify="left",
            anchor="w",
            wraplength=370,
            padx=8,
            pady=6,
        )

    #  BUTTON HANDLER 
    def _on_button(self, label):
        if self.controller:
            self.controller.handle_input(label)

    #  PUBLIC METHODS — called by controller

    def update_display(self, expression, history_hint=""):
        self.expr_var.set(expression)
        self.history_var.set(history_hint)

    def show_error(self, message):
        self.expr_var.set(f"Error: {message}")
        self.history_var.set("")

    def show_history(self, history):
        if not history:
            text = "No history yet."
        else:
            lines = [f"{i+1}. {h['expression']} = {h['result']}"
                     for i, h in enumerate(history[-6:])]
            text = "\n".join(lines)

        self.history_popup.config(text=text)
        self.history_popup.place(x=10, y=60, width=380)
        self.root.after(3500, self.history_popup.place_forget)
