"""
Calculator View
Handles all display and user input.
"""


class CalculatorView:
    def show_menu(self):
        print("\n" + "=" * 45)
        print("       ENHANCED MVC CALCULATOR")
        print("=" * 45)
        print("  1. Addition          (+)")
        print("  2. Subtraction       (-)")
        print("  3. Multiplication    (*)")
        print("  4. Division          (/)")
        print("  5. Square Root       (sqrt)")
        print("  6. Power             (^)")
        print("  7. Modulo            (%)")
        print("  8. View History")
        print("  9. Clear History")
        print("  0. Exit")
        print("=" * 45)

    def get_choice(self):
        return input("Enter your choice: ").strip()

    def get_number(self, prompt="Enter number: "):
        while True:
            try:
                return float(input(prompt))
            except ValueError:
                self.show_error("Invalid input. Please enter a valid number.")

    def show_result(self, expression, result):
        print(f"\n  Result: {expression} = {result}")

    def show_error(self, message):
        print(f"\n  [ERROR] {message}")

    def show_history(self, history):
        print("\n" + "-" * 45)
        print("  OPERATION HISTORY")
        print("-" * 45)
        if not history:
            print("  No history yet.")
        else:
            for i, entry in enumerate(history, 1):
                print(f"  {i}. {entry['expression']} = {entry['result']}")
        print("-" * 45)

    def show_message(self, message):
        print(f"\n  {message}")
