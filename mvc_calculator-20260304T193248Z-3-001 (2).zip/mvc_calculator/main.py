import tkinter as tk
from view.calculator_gui import CalculatorGUI
from controller.gui_controller import GUIController


def main():
    root = tk.Tk()
    # Center window on screen
    root.geometry("420x520")
    root.eval("tk::PlaceWindow . center")

    view = CalculatorGUI(root)
    controller = GUIController(view)

    root.mainloop()


if __name__ == "__main__":
    main()
