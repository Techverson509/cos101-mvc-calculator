from model.calculator_model import CalculatorModel
from view.calculator_view import CalculatorView


class CalculatorController:
    def __init__(self):
        self.model = CalculatorModel()
        self.view = CalculatorView()

    def run(self):
        while True:
            self.view.show_menu()
            choice = self.view.get_choice()

            if choice == "0":
                self.view.show_message("Goodbye!")
                break
            elif choice == "1":
                self._binary_operation("addition", "+", self.model.add)
            elif choice == "2":
                self._binary_operation("subtraction", "-", self.model.subtract)
            elif choice == "3":
                self._binary_operation("multiplication", "*", self.model.multiply)
            elif choice == "4":
                self._binary_operation("division", "/", self.model.divide)
            elif choice == "5":
                self._unary_operation("sqrt", "sqrt", self.model.sqrt)
            elif choice == "6":
                self._binary_operation("power", "^", self.model.power)
            elif choice == "7":
                self._binary_operation("modulo", "%", self.model.modulo)
            elif choice == "8":
                history = self.model.get_history()
                self.view.show_history(history)
            elif choice == "9":
                self.model.clear_history()
                self.view.show_message("History cleared.")
            else:
                self.view.show_error("Invalid choice. Please select a valid option.")

    def _binary_operation(self, name, symbol, operation):
        a = self.view.get_number("Enter first number: ")
        b = self.view.get_number("Enter second number: ")
        try:
            result = operation(a, b)
            expression = f"{a} {symbol} {b}"
            # Round result for cleaner display
            display_result = round(result, 10)
            self.view.show_result(expression, display_result)
            self.model.save_to_history(expression, display_result)
        except ValueError as e:
            self.view.show_error(str(e))

    def _unary_operation(self, name, symbol, operation):
        a = self.view.get_number("Enter number: ")
        try:
            result = operation(a)
            expression = f"{symbol}({a})"
            display_result = round(result, 10)
            self.view.show_result(expression, display_result)
            self.model.save_to_history(expression, display_result)
        except ValueError as e:
            self.view.show_error(str(e))
