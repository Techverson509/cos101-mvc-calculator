from model.calculator_model import CalculatorModel


class GUIController:
    def __init__(self, view):
        self.model = CalculatorModel()
        self.view = view
        self.view.set_controller(self)

        # Internal state
        self._current_input = ""     # What user is currently typing
        self._pending_op = None      # +, -, *, /, ^, %
        self._first_value = None     # First operand stored
        self._just_evaluated = False # Did we just press "=" ?
        self._sqrt_mode = False      # Waiting for sqrt input?

        self.view.update_display("0")

    #  MAIN DISPATCHER
    def handle_input(self, label):
        # Numbers and decimal point
        if label.isdigit() or label == ".":
            self._handle_digit(label)

        elif label in ("+", "-", "*", "/", "x^y", "mod"):
            self._handle_operator(label)

        elif label == "sqrt":
            self._handle_sqrt()

        elif label == "=":
            self._handle_equals()

        elif label == "CE":
            self._handle_clear()

        elif label == "⌫":
            self._handle_backspace()

        elif label == "+/-":
            self._handle_negate()

        elif label == "History":
            self.view.show_history(self.model.get_history())

        elif label == "Clr Hist":
            self.model.clear_history()
            self.view.update_display(self._current_input or "0", "History cleared")

    #  HANDLERS

    def _handle_digit(self, digit):
        if self._just_evaluated:
            self._current_input = ""
            self._just_evaluated = False

        # Prevent multiple dots
        if digit == "." and "." in self._current_input:
            return

        self._current_input += digit
        self.view.update_display(self._current_input, self._hint())

    def _handle_operator(self, op):
        if self._current_input == "" and self._first_value is None:
            return

        # Chain operations: evaluate pending first
        if self._first_value is not None and self._current_input:
            self._evaluate()

        if self._current_input:
            self._first_value = float(self._current_input)

        self._pending_op = op
        self._current_input = ""
        self._just_evaluated = False
        self.view.update_display("0", self._hint())

    def _handle_sqrt(self):
        val_str = self._current_input or (str(self._first_value) if self._first_value is not None else "")
        if not val_str:
            return
        try:
            val = float(val_str)
            result = self.model.sqrt(val)
            expr = f"sqrt({val})"
            display_result = self._fmt(result)
            self.model.save_to_history(expr, display_result)
            self.view.update_display(str(display_result), expr)
            self._current_input = str(display_result)
            self._first_value = None
            self._pending_op = None
            self._just_evaluated = True
        except ValueError as e:
            self.view.show_error(str(e))

    def _handle_equals(self):
        if self._first_value is None or not self._current_input:
            return
        self._evaluate()

    def _evaluate(self):
        try:
            a = self._first_value
            b = float(self._current_input)
            op = self._pending_op

            ops = {
                "+":    self.model.add,
                "-":    self.model.subtract,
                "*":    self.model.multiply,
                "/":    self.model.divide,
                "x^y":  self.model.power,
                "mod":  self.model.modulo,
            }

            result = ops[op](a, b)
            display_result = self._fmt(result)

            symbols = {"+": "+", "-": "-", "*": "×", "/": "÷", "x^y": "^", "mod": "%"}
            expr = f"{self._fmt(a)} {symbols[op]} {self._fmt(b)}"

            self.model.save_to_history(expr, display_result)
            self.view.update_display(str(display_result), expr)

            self._current_input = str(display_result)
            self._first_value = None
            self._pending_op = None
            self._just_evaluated = True

        except ValueError as e:
            self.view.show_error(str(e))
            self._handle_clear()
        except Exception as e:
            self.view.show_error("Unexpected error")
            self._handle_clear()

    def _handle_clear(self):
        self._current_input = ""
        self._first_value = None
        self._pending_op = None
        self._just_evaluated = False
        self.view.update_display("0")

    def _handle_backspace(self):
        if self._just_evaluated:
            self._handle_clear()
            return
        self._current_input = self._current_input[:-1]
        self.view.update_display(self._current_input or "0", self._hint())

    def _handle_negate(self):
        if self._current_input and self._current_input != "0":
            if self._current_input.startswith("-"):
                self._current_input = self._current_input[1:]
            else:
                self._current_input = "-" + self._current_input
            self.view.update_display(self._current_input, self._hint())

    #  HELPERS
    def _fmt(self, value):
        """Format number: remove .0 for integers."""
        if isinstance(value, float) and value.is_integer():
            return int(value)
        return round(value, 8)

    def _hint(self):
        """Show pending operation hint above display."""
        if self._first_value is not None and self._pending_op:
            symbols = {"+": "+", "-": "-", "*": "×", "/": "÷", "x^y": "^", "mod": "%"}
            return f"{self._fmt(self._first_value)} {symbols.get(self._pending_op, self._pending_op)}"
        return ""
