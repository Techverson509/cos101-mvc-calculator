import math


class CalculatorModel:
    def __init__(self):
        self.history = []

    def add(self, a, b):
        return a + b

    def subtract(self, a, b):
        return a - b

    def multiply(self, a, b):
        return a * b

    def divide(self, a, b):
        if b == 0:
            raise ValueError("Division by zero is not allowed.")
        return a / b

    def sqrt(self, a):
        if a < 0:
            raise ValueError("Cannot compute square root of a negative number.")
        return math.sqrt(a)

    def power(self, a, b):
        return math.pow(a, b)

    def modulo(self, a, b):
        if b == 0:
            raise ValueError("Modulo by zero is not allowed.")
        return a % b

    def save_to_history(self, expression, result):
        self.history.append({"expression": expression, "result": result})

    def get_history(self):
        return self.history

    def clear_history(self):
        self.history = []
